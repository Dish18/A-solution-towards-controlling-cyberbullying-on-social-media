from flask import Flask,request
import json
import PIL.Image as Image
import io
from io import BytesIO
import base64
import jpype
from jpype import *
import mysql.connector as mc
import tensorflow as tf
import numpy as np

#to track SA time
import datetime

#import for WM
import smtplib,ssl


#imports for OCR part:
import pytesseract
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
import shutil
import os
import random
try:
 from PIL import Image
except ImportError:
 import Image

#imports for video subtitle extraction part
import speech_recognition as sr
import moviepy.editor as mp

db=mc.connect(host="localhost",user="root",password="Angi@1975$",database="mpdb")

cursor_obj=db.cursor()

#BERT Integration
from transformers import TFDistilBertForSequenceClassification
from transformers import DistilBertTokenizerFast
tokenizer = DistilBertTokenizerFast.from_pretrained('distilbert-base-uncased')

#mention the model paths
model_path1="bert-1-model-1-e"
model_path2="bert-2-model-2"

#load the models
loaded_model1 = TFDistilBertForSequenceClassification.from_pretrained(model_path1)
loaded_model2= TFDistilBertForSequenceClassification.from_pretrained(model_path2)

#useful during prediction
non_hate_codes=[3,5]
toxicities=["toxic","severely toxic","obscene","threat","insult","identity_hate"]
wm_toxicities=["toxic","obscene","insult"]

#run Java code from Python by launching JVM
startJVM("C:\\Program Files\\Java\\jdk-18.0.1.1\\bin\\server\\jvm.dll", "-ea")
java.lang.System.out.println("Calling Java Print from Python using Jpype!")
FileOutputStream=jpype.JClass("java.io.FileOutputStream")

  
###for text handling:
import pickle
import re
'''
#handle the pickle file required for the pre-processing
with open('Emoji_Dict.p', 'rb') as fp:
    Emoji_Dict = pickle.load(fp)
Emoji_Dict = {v: k for k, v in Emoji_Dict.items()}

#function to convert emojis to corresponding text
def convert_emojis_to_word(text):
    for emot in Emoji_Dict:
        text = re.sub(r'('+emot+')', "_".join(Emoji_Dict[emot].replace(",","").replace(":","").split()), text)
    return text
'''

#function to remove emojis:
def remove_emoji(string):
    emoji_pattern = re.compile("["
                           u"\U0001F600-\U0001F64F" # emoticons
                           u"\U0001F300-\U0001F5FF" # symbols & pictographs
                           u"\U0001F680-\U0001F6FF" # transport & map symbols
                           u"\U0001F1E0-\U0001F1FF" # flags (iOS)
                           u"\U00002702-\U000027B0"
                           u"\U000024C2-\U0001F251"
                           "]+", flags=re.UNICODE)
    return emoji_pattern.sub(r'', string)

#acceptable file extensions
video_extensions=['.mp4','.wmv','.avi']
image_extensions=['.jpg','.jpeg','.png','.jfif']
image_save_path="D:/sem8/major project/codes/v4/flask-server/uploads/images/"
video_save_path="D:/sem8/major project/codes/v4/flask-server/uploads/videos/"

app=Flask(__name__)

#function to retrieve the bully's mail id to send a warning mail
def get_bully_email(usr):
    
    #fetch the mailID of this user
    cursor_obj.execute("select email from user where username=%s",(usr, ))
    
    try:
        recs=cursor_obj.fetchall()
        return recs[0][0]
                
    except:
        print("Error...")
        return None


#code to send warning mail to the reported user
def send_mail(usr):          
    from_address = 'dont.reply.us.999@gmail.com'
    to_address = get_bully_email(usr)
    port = 465  # For SSL
    smtp_server = "smtp.gmail.com"
    password = "cn_project@2021$"
    message = """\
    Our system detected hate speech in your post.
    Posting too much of hate content can even suspend your account."""
    context = ssl.create_default_context()
    with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
        server.login(from_address, password)
        server.sendmail(from_address,to_address, message)
       
#code to check if a username is in the record of cyberbullies
def check_if_bully(username):
    cursor_obj.execute('select * from cyberbullies')    
    try:
        recs=cursor_obj.fetchall()
        for rec in recs:
            usr=rec[0]
            suspend_hr=rec[1]
            if usr==username:
                #print("user in cyberbullies table detected")
                current_hr=datetime.datetime.now().hour
                #print("suspended at: ",suspend_hr)
                #print("current time: ",current_hr)
                if suspend_hr!=-1:
                    #print("user's acc is still suspended")
                    temp=suspend_hr+2
                    #print(temp)
                    if temp<=current_hr:
                        #print("Suspension time over!")
                        cursor_obj.execute("update cyberbullies set suspendedHr=%s where username=%s",(-1,username))
                        #print("user's acc is no longer suspended")
                        return False
                    else:
                        #print("user's suspending time ny over")
                        return True
                else:
                    return False
        return False
                    
    except:
        print("Error...")
    


def check(test_sentence):
    #pass the text to BERT models and check if it is bullying?    
    predict_input = tokenizer.encode(test_sentence,
                                 truncation=True,
                                 padding=True,
                                 return_tensors="tf")

    tf_output = loaded_model1.predict(predict_input)[0]
    tf_prediction = tf.nn.softmax(tf_output, axis=1).numpy()
    ans=np.argmax(tf_prediction,axis=1)

    if ans[0] in non_hate_codes:
        return "NH"   
    else:   
        tf_output = loaded_model2.predict(predict_input)[0]
        tf_prediction = tf.nn.softmax(tf_output, axis=1).numpy()
        cat=np.argmax(tf_prediction,axis=1)  
        if toxicities[cat[0]] in wm_toxicities:            
            return "WM" 
        else:
            return "SA"    


@app.route("/handleTextInput",methods=["POST"])
def text_input_handler():
    username=request.json['userName']
    print("User logged in is: ",username)
    
    textInput=request.json['textInput']
    print(textInput)
   
    #code to pre-process text input
    finalText=remove_emoji(textInput)
    status=check(finalText)
    print(status)
    

    if status=="WM":
        print("Warning mail will be sent")
        #send_mail(username)
    elif status=="SA":
        curr=datetime.datetime.now().hour
        print("Warning mail will also be sent")
        #send_mail(username)
        #enter into bully table if SA
        try:
            cursor_obj.execute("INSERT INTO cyberbullies VALUES (%s,%s)", (username,curr))
            db.commit()
            print("Record inserted to cyberbully table successfully!!!")
        except:
            db.rollback()
    
    return {"isBully":status}

@app.route("/handleImageInput",methods=["POST"])
def image_input_handler():
    
    #user details
    username=request.json['userName']
    print("User logged in is: ",username)
    
    
    #decoding
    fcontent=request.json['fileContent']
    
    
    #print("File name: ",fname)
    
    lis=fcontent.split(",") #done to remove base64 in the string
    
    fcontent_base64=lis[1]
    fcontent_base64_bytes_format = fcontent_base64.encode('utf-8')  #convert the string of file content to bytes
    
    #print("File content: ",fcontent_base64)
    fname=request.json['fileName']
    final_path=image_save_path+fname
            
    decoded = base64.b64decode(fcontent_base64_bytes_format)
    image = Image.open(io.BytesIO(decoded))
    image.save(final_path)

    #OCR of image to extract text
    extractedInformation = pytesseract.image_to_string(Image.open(final_path))
    valid_text=extractedInformation.strip()

    #check for bullying
    if valid_text!='':
        status=check(valid_text)    #memes with text
        if status=="WM":
            print("A warning mail will be sent")
            #send_mail(username)
        elif status=="SA":
            curr=datetime.datetime.now().hour
            print("A warning mail will also be sent")
            #send_mail(username)
            #enter into bully table if SA
            try:
                cursor_obj.execute("INSERT INTO cyberbullies VALUES (%s,%s)", (username,curr))
                db.commit()
                print("Record inserted to cyberbully table successfully!!!")
            except:
                db.rollback()
    else:
        status="NH" #just selfies w/o text

    return {"isBully":status}

@app.route("/handleVideoInput",methods=["POST"])
def video_input_handler():

    #user details
    username=request.json['userName']
    print("User logged in is: ",username)

    #decoding
    fcontent=request.json['fileContent']
    
    #print("File name: ",fname)
    
    lis=fcontent.split(",") #done to remove base64 in the string
    
    fcontent_base64=lis[1]
    fcontent_base64_bytes_format = fcontent_base64.encode('utf-8')  #convert the string of file content to bytes
    
    #print("File content: ",fcontent_base64)
    fname=request.json['fileName']
    final_path=video_save_path+fname

    #Java code-running it from Python to save the video file        
    out = FileOutputStream(final_path)

    #decode the base64 bytes
    decoded = base64.b64decode(fcontent_base64_bytes_format)
    out.write(decoded)
    out.close()   
    
    #extract subtitles from video to get text
    try:
        clip = mp.VideoFileClip(final_path)
        clip.audio.write_audiofile(r"converted.wav")
        r = sr.Recognizer()
        audio = sr.AudioFile("converted.wav")
        with audio as source:
            audio_file = r.record(source)
        result = r.recognize_google(audio_file)
        status=check(result)
        if status=="WM":
            print("A warning mail will be sent")
            #send_mail(username)
        elif status=="SA":
            curr=datetime.datetime.now().hour
            print("A warning mail will also be sent")
            #send_mail(username)
            #enter into bully table if SA
            try:
                cursor_obj.execute("INSERT INTO cyberbullies VALUES (%s,%s)", (username,curr))
                db.commit()
                print("Record inserted to cyberbully table successfully!!!")
            except:
                db.rollback()        
    except:
        status="NH"
        
    return {"isBully":status}

@app.route("/login",methods=["POST"])
def login():
    username=request.json['username']
    password=request.json['password']

    #check if the username already exists
    cursor_obj.execute('select * from user')    
    try:
        recs=cursor_obj.fetchall()
        for rec in recs:
            usr=rec[2]
            passwd=rec[1]
            if(usr==username):
                if(passwd==password):
                    bullyCheck=check_if_bully(username)
                    #print(bullyCheck)
                    if bullyCheck==True:
                        return {"isUser":"bully"}
                    else:
                        return {"isUser":"yes"}
                else:
                    return {"isUser":"wrong"}
    except:
        print("Error...")    
    
    return {"isUser":"no"}

@app.route("/signup",methods=["POST"])
def sign_up_user():
    username=request.json['userName']
    password=request.json['password']
    mail=request.json['mail']
    print("User Name: ",username)
    print("Password: ",password)
    print("Mail: ",mail)
    #store details in mpdb user table
    
    #check if the username already exists
    cursor_obj.execute('select * from user')    
    try:
        recs=cursor_obj.fetchall()
        for rec in recs:
            existing_mail=rec[0]
            existing_username=rec[2]
            if(existing_username==username or mail==existing_mail):
                return {"isAccCreated":"exists"}
    except:
        print("Error...")

    #create a new account if username does not exist
    try:        
        cursor_obj.execute("INSERT INTO user VALUES (%s, %s, %s)", (mail,password,username))
        db.commit()
        print("Record inserted to mpdb database successfully!!!")
    except:
        db.rollback()

    
    return {"isAccCreated":"yes"}
    




if __name__=="__main__":
    app.run(debug=True)
