import React from "react";
import { TopSection } from "./topSection";
import styled, { css } from 'styled-components';
import { Footer } from "../../components/footer";
import { Marginer } from "../../components/marginer";
import { ServicesSection } from "./servicesSection";
import { MoreAboutSection } from "./moreAboutSection";


const PageContainer=styled.div` 
    width:100%;
    height:100%;
    display:flex;
    flex-direction:column;
`;
export function Homepage(props)
{
    return(
     <PageContainer>
         <TopSection/>
         <ServicesSection/>
         <Marginer direction="vertical" margin="2em" />
         <MoreAboutSection />
        <Marginer direction="vertical" margin="8em" />
        <Footer />
    </PageContainer>
    ); 
}