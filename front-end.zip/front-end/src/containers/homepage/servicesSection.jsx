import React from "react";
import styled from "styled-components";

import { Element } from "react-scroll";
import { Marginer } from "../../components/marginer";
import { OurService } from "../../components/ourService";
import { SectionTitle } from "../../components/sectionTitle";

import Service1Img from "../../assets/illustrations/Meme.jpeg";
import Service2Img from "../../assets/illustrations/Image.jpeg";
import Service3Img from "../../assets/illustrations/Videos.jpeg";


const ServicesContainer=styled(Element)`
width: 100%;
min-height: 1400px;
display: flex;
flex-direction: column;
align-items: center;
  padding: 10px 0;
`;
export function ServicesSection(props)
{
    return (
        <ServicesContainer name="servicesSection">
        <SectionTitle>Cyber Bullying Controlling Services</SectionTitle>
        <Marginer direction="vertical" margin="3em" />
        <OurService
          title="CyberBullying for Text"
          description="Cyberbullying detection on text posts(text data) through hate content 
          identification followed by toxicity level classification using BERT-a high-level NLP model 
          at the Flask back-end"
          imgUrl={Service1Img}
        />
        <OurService
          title="Cyberbullying for memes"
          description="Cyberbullying detection on images with text(targetting memes) by extracting the 
          text by OCR and then performing hate content identification followed by toxicity level classification
           using BERT-a high-level NLP model at the Flask back-end"
          imgUrl={Service2Img}
          isReversed
        />
        <OurService
          title="Cyberbullying for videos"
          description="Cyberbullying detection on videos by extracting subtitles from the audio and then 
          passing the text to perform hate content identification followed by toxicity level classification using BERT-a high-level NLP model at the Flask back-end"
          imgUrl={Service3Img} 
        />
      </ServicesContainer>
    );
}