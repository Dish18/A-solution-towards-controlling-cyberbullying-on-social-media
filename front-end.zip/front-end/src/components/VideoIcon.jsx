import * as React from "react";
import { styled } from "@mui/material/styles";
import IconButton from "@mui/material/IconButton";
import Stack from "@mui/material/Stack";
import PlayArrowIcon from "@mui/icons-material/PlayArrow";

const Input = styled("input")({
  display: "none"
});

export default function UploadButtons() {
  return (
    <Stack direction="row" alignItems="center" spacing={2}>
      <label htmlFor="icon-button-file">
        <Input accept="video/mp4" id="icon-button-file" type="file" />
        <IconButton
          style={{
            color: "white",
            border: "2px solid black",
            backgroundColor: "red"
          }}
          aria-label="upload video"
          component="span"
        >
          <PlayArrowIcon />
        </IconButton>
      </label>
    </Stack>
  );
}
