import React from "react";

function Break() {
  return (
    <div>
      <br />
      <br />
    </div>
  );
}

export default Break;
