import React from "react";
import styled from "styled-components";
import CyberLogo from "../../assets/logo/logo8.jpeg";


const LogoContainer=styled.div`
    display:flex;
    flex-direction:column;
`;
const LogoImg=styled.img`
    width:100%;
    height:8em;

`;

export function Logo(props){
    return (
        <LogoContainer>
            <LogoImg src={CyberLogo}/>
            
            
            
        </LogoContainer>
        
    )
}