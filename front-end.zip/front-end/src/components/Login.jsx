import React, { useState } from "react";
import Break from "./Break";
import {useNavigate} from 'react-router-dom';

function Login() {

  let navigate=useNavigate();

  const [userName, setUserName] = useState("");
  const [password, setPassword] = useState("");
  const [isMousedOver, setIsMousedOver] = useState(false);
  const [isIncorrectCredentials, setIsIncorrectCredentials] = useState(false);
  const [accSuspended,setAccSuspended]=useState(false);

  function handleMouseOver() {
    setIsMousedOver(true);
  }

  function handleMouseOut() {
    setIsMousedOver(false);
  }

  function handleChangeUserName(event) {
    setUserName(event.target.value);
  }

  function handleChangePassword(event) {
    setPassword(event.target.value);
  }

  function handleClick(event) {
    // console.log(userName);
    // console.log(password);

    fetch("/login",{
      'method':'POST',
       headers : {
      'Content-Type':'application/json'
    },
    body:JSON.stringify({"username":userName,"password":password})
  })
  .then(response => response.json())
  .then(data=>{
    if(data.isUser==="yes")
      navigate('/user-dashboard',{state:{user:userName}}) 
    else if(data.isUser==="no")
      navigate('/signup')
    else if(data.isUser==="wrong")
      setIsIncorrectCredentials(true); 
    else if(data.isUser==="bully")
      setAccSuspended(true);  


  })
  .catch(error => console.log(error))
    
  event.preventDefault();
  }

  return (
    
    <div className="container body-class bg-class">
     <h1>Login</h1>
     <Break/>
      <form onSubmit={handleClick}>
        <input
          onChange={handleChangeUserName}
          type="text"
          placeholder="Username"
          value={userName}
        />
        
        <input
          onChange={handleChangePassword}
          type="password"
          placeholder="Password"
          value={password}
        />
        {isIncorrectCredentials && <h2>Sorry,your username and password don't match</h2>}
        {accSuspended && <h2>Your account is currently suspended.Try again later.</h2>}
        <br/>

       
        <button
          type="submit"
          onMouseOver={handleMouseOver}
          onMouseOut={handleMouseOut}
          style={{ backgroundColor: isMousedOver && "#F7CCAC" }}
          className="lsbtn"
        >
          Submit
        </button>
        
      </form>
    </div>
    
  );
}

export default Login;
