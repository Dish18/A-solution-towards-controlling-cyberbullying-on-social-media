import React, { useState } from "react";
import Break from "./Break";
import {useNavigate} from 'react-router-dom';

function SignUp() {
  let navigate=useNavigate();

  const [userName, setUserName] = useState("");
  const [password, setPassword] = useState("");
  const [mail, setMail] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [isMousedOver, setIsMousedOver] = useState(false);
  const [isConfirmPassowrd, setIsConfirmPassword] = useState(false);
  const [isExists,setIsExists]=useState(false);
  const [canNavigate,setCanNavigate]=useState(false);

  function handleMouseOver() {
    setIsMousedOver(true);
  }

  function handleChangeMail(event){
    setMail(event.target.value);
  }

  function handleMouseOut() {
    setIsMousedOver(false);
  }

  function handleChangeUserName(event) {
    setUserName(event.target.value);
  }

  function handleChangePassword(event) {
    setPassword(event.target.value);
  }

  function handleChangeConfirmPassword(event) {
    setConfirmPassword(event.target.value);
  }

  function handleClick(event) {
    console.log(userName);
    console.log(password);
    console.log(confirmPassword);
    console.log(mail);
    if(confirmPassword==password){

      fetch("/signup",{
        'method':'POST',
         headers : {
        'Content-Type':'application/json'
      },
      body:JSON.stringify({"userName":userName,"password":password,"mail":mail})
    })
    .then(response => response.json())
    .then(data=>{       
      if(data.isAccCreated=="exists"){
        setIsExists(true);
      }
      else if(data.isAccCreated=="yes"){
        setCanNavigate(true);
      }

    })
    .catch(error => console.log(error))

    canNavigate && navigate('/user-dashboard',{state:{user:userName}});

    }
    else{
      setIsConfirmPassword(true);
    }    
    event.preventDefault();
  }

  return (
    <div className="container body-class bg-class">
    <h1>Sign Up</h1>
    <Break/>
      <form onSubmit={handleClick}>
        <input
          onChange={handleChangeUserName}
          type="text"
          placeholder="Username"
          value={userName}
        />
        <input
          onChange={handleChangeMail}
          type="email"
          placeholder="Email ID"
          value={mail}
        />
        <input
          onChange={handleChangePassword}
          type="password"
          placeholder="Password"
          value={password}
        />
        <input
          onChange={handleChangeConfirmPassword}
          type="password"
          placeholder="Confirm Password"
          value={confirmPassword}
        />
        <br/>
        
        <button
          type="submit"
          onMouseOver={handleMouseOver}
          onMouseOut={handleMouseOut}
          style={{ backgroundColor: isMousedOver && "#F7CCAC" }}
          className="lsbtn"
        >
          Submit
        </button>
        
      </form>
      <br/>
      {isConfirmPassowrd && <h2>Confirm Password and Password must be same</h2>}
      {isExists && <h2>Sorry,try a different username.An account with this username or emailID already exists</h2>}
    </div>
  );
}

export default SignUp;
