import React, { useState } from "react";
import { styled } from "@mui/material/styles";
import Button from "@mui/material/Button";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import CardHeader from "@mui/material/CardHeader";
import IconButton from "@mui/material/IconButton";
import TextFieldsIcon from "@mui/icons-material/TextFields";
import ImageIcon from "./ImageIcon";
import VideoIcon from "./VideoIcon";
import InputEmoji from "react-input-emoji";
import { useFilePicker } from "use-file-picker";
import Break from "./Break";
import { Alert } from "@mui/material";




const ExpandMore = styled((props) => {
  const { expand, ...other } = props;
  return <IconButton {...other} />;
})(({ theme, expand }) => ({
  transform: !expand ? "rotate(0deg)" : "rotate(180deg)",
  marginLeft: "auto",
  transition: theme.transitions.create("transform", {
    duration: theme.transitions.duration.shortest
  })
}));

function NewPost(props) {
  const [isPostArea, setIsPostArea] = useState(false);
  const [text, setText] = useState("");
  const [isFileUpload, setIsFileUpload] = useState(false);
  const [isBully,setIsBully] = useState("");
  const userName=props.usr;



  
  let videoExtensions=['mp4','wmv','avi']
  let imageExtensions=['jpg','jpeg','png','jfif']

 

  const [openFileSelector, { filesContent, loading, errors }] = useFilePicker({
    readAs: "DataURL",
    limitFilesConfig: { max: 1 },
    // minFileSize: 1,
    maxFileSize: 50 // in megabytes
  });

  if (loading) {
    return <div>Loading...</div>;
  }

  if (errors.length) {
    return <div>Error...</div>;
  }

  function handlePostClick() {
    
    //text input
    if(isPostArea)
    {
        

      fetch("/handleTextInput",{
        'method':'POST',
         headers : {
        'Content-Type':'application/json'
      },
      body:JSON.stringify({"textInput":text,"userName":userName})
    })
    .then(response => response.json())
    .then(data=>{
      setIsBully(data.isBully);  
      console.log(data.isBully);

    })
    .catch(error => console.log(error))
  
    }
    
    //file input
     
    if(isFileUpload)
    {
      handleFileUpload(); 
    }
           
    }
           
      
  
    
  function handlePostArea() {
    setIsPostArea(!isPostArea);
  }

  function handleFileUpload() {
    //TO GET DETAILS OF THE IMAGE/VIDEO FILE UPLOADED
    //send the foll. details in the form of a JSON object to Flask
    filesContent.forEach((file) => {
      // console.log({
      //   name: file.name,
      //   content: file.content
      // });
      
      let fileName=file.name;
      let fileContent=file.content;
     
      let arr=file.name.split('.')

      if(imageExtensions.includes(arr[1]))
      {
        //image input
        fetch("/handleImageInput",{
          'method':'POST',
           headers : {
          'Content-Type':'application/json'
        },
        body:JSON.stringify({"fileName":fileName,"fileContent":fileContent,"userName":userName})
      })
      .then(response => response.json())
      .then(data=>{
        setIsBully(data.isBully);  
        console.log(data.isBully);   
      })
      .catch(error => console.log(error))    
      }        
      
      else if(videoExtensions.includes(arr[1]))
      {
        //video input
        fetch("/handleVideoInput",{
          'method':'POST',
           headers : {
          'Content-Type':'application/json'
        },
        body:JSON.stringify({"fileName":fileName,"fileContent":fileContent,"userName":userName})
      })
      .then(response => response.json())
      .then(data=>{
        setIsBully(data.isBully); 
        console.log(data.isBully);     
      })
      .catch(error => console.log(error))    
      }    

      }
      
    );
  }

  return (
    <div>
    <Card sx={{ maxWidth: 1000, marginTop: "3em",backgroundColor:"#D3DEDC"}}>
      <CardHeader style={{color:"black"}} title="Create a new post" />
      {isPostArea && (
        <InputEmoji onChange={setText} placeholder="Type your post here..." />
      )}

      <Button
        style={{ margin: "2em" }}
        variant="contained"
        size="small"
        onClick={handlePostClick}
      >
        Post
      </Button>
      <Button
        onClick={handlePostArea}
        style={{ color: "#FBF8F1", backgroundColor: "#573391" }}
        size="small"
      >
        <TextFieldsIcon />
      </Button>
      <Button
        onClick={() => {
          isPostArea && setIsPostArea(false);
          setIsFileUpload(true);
          openFileSelector();
        }}
        size="small"
      >
        <ImageIcon />
      </Button>

      <Button
        onClick={() => {
          isPostArea && setIsPostArea(false);
          setIsFileUpload(true);
          openFileSelector();
        }}
        size="small"
      >
        <VideoIcon />
      </Button>

      <CardActions disableSpacing>
        <ExpandMore />
      </CardActions>
    </Card>

    <Break/>   

    {/* <Alert severity="warning">Warning mail on bullying</Alert>  */}

    {isBully==="NH" && <Alert severity="success">No bullying content detected in the post!</Alert>}   
    {isBully==="WM" && <Alert severity="warning">Warning mail on bullying</Alert>}   
    {isBully==="SA" && <Alert severity="error">Suspend account</Alert>}  
    
    
    </div>
  );
}    

export default NewPost;
