import React from "react";
import NewPost from "./NewPost";
import Break from "./Break";
import {useLocation} from 'react-router-dom';




function UserDashboard() {
  const location = useLocation();
  const userName=location.state.user;
  console.log(userName);
  
  return (
    <div>
     
      <div className="center">
        <Break />
        <NewPost usr={userName}/>
        <Break />        
      </div>
      
    </div>
  );
}

export default UserDashboard;
