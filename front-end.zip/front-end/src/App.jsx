import React from "react";
import UserDashboard from "./components/UserDashboard";
import {Homepage} from "./containers/homepage";
import Login from "./components/Login";
import SignUp from "./components/SignUp";
import { BrowserRouter, Routes ,Route } from 'react-router-dom';



function App() {
  
  // fetch("/check").then(
  //   res=>res.json()
  // ).then(
  //   data=>{      
  //     console.log(data.isBully[0]);
  //   }
  // ) 

  return(
  <BrowserRouter>
        <Routes>
            {/* home route */}
            <Route path="/" element={<Homepage/>} />              
            {/* login route */}
            <Route path="/login" element={<Login/>} />
            {/* signup route */}
            <Route path="/signup" element={<SignUp/>} />
            {/* user dashboard route */}
            <Route path="/user-dashboard" element={<UserDashboard/>} />
        </Routes>
  </BrowserRouter>
  ) 
 
}

export default App;
